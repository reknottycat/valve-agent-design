import sys,json,numpy as np
from pathlib import Path
sys.path.insert(0,'/workspace/shared/valve-gmsh-trial-20261023/vendor');import gmsh
r=Path(__file__).parent;gmsh.initialize();gmsh.model.occ.importShapes('/workspace/scratch/634aa36792d6/attachments/2618578e-bbba-4a39-81cb-899300c65163/AGR1_open_seal_omitted_proxy_main_mm.step');gmsh.model.occ.synchronize();gmsh.merge(str(r/'fresh-local-surface.msh'));nt,cs,_=gmsh.model.mesh.getNodes();pos={int(t):p for t,p in zip(nt,np.array(cs).reshape(-1,3))};res={'edges':{}}
for e in [280,282,294]:
 ty,_,nd=gmsh.model.mesh.getElements(1,e);n=np.array(nd[0]).reshape(-1,2);x=np.array([[pos[int(k)] for k in row] for row in n]);res['edges'][str(e)]={'adjacent_faces':gmsh.model.getAdjacencies(1,e)[0].tolist(),'segments':len(n),'length_quantiles_mm':np.percentile(np.linalg.norm(x[:,1]-x[:,0],axis=1),[0,50,100]).tolist()}
_,ts,ns=gmsh.model.mesh.getElements(2,118);tri=np.array(ns[0]).reshape(-1,3);x=np.array([[pos[int(k)] for k in row] for row in tri]);ed=np.array([np.linalg.norm(x[:,a]-x[:,b],axis=1) for a,b in [(0,1),(0,2),(1,2)]]);area=np.linalg.norm(np.cross(x[:,1]-x[:,0],x[:,2]-x[:,0]),axis=1)/2;asp=ed.max(0)**2/(2*area);res['worst_triangles']=[{'id':int(ts[0][i]),'aspect':float(asp[i]),'xyz_mm':x[i].tolist(),'node_entities':[list(gmsh.model.mesh.getNode(int(n))[2:]) for n in tri[i]]} for i in np.argsort(asp)[-5:]]
(r/'evidence/boundary-diagnostic.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2));gmsh.finalize()

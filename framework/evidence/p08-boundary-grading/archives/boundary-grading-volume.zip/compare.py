import sys,json,numpy as np
sys.path.insert(0,'/workspace/shared/valve-gmsh-trial-20261023/vendor');import gmsh
from pathlib import Path
r=Path(__file__).parent;gmsh.initialize();out={}
for label,path in [('baseline',Path('/workspace/shared/valve-retainer-local-surface-20261023/fresh-local-surface.msh')),('graded',r/'fresh-local-surface.msh')]:
 gmsh.clear();gmsh.open(str(path));nt,cs,_=gmsh.model.mesh.getNodes();pos={int(t):p for t,p in zip(nt,np.array(cs).reshape(-1,3))};out[label]={}
 for f in [117,118,126]:
  ty,ts,ns=gmsh.model.mesh.getElements(2,f);tri=np.array(ns[0]).reshape(-1,3);xyz=np.array([[pos[int(n)] for n in t] for t in tri]);edges=np.array([np.linalg.norm(xyz[:,a]-xyz[:,b],axis=1) for a,b in [(0,1),(0,2),(1,2)]]);area=np.linalg.norm(np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]),axis=1)/2;aspect=edges.max(0)**2/(2*area);cent=xyz.mean(1);rho=np.hypot(cent[:,0]-300,cent[:,1]);d=cent[:,2]-79 if f==117 else (rho-110.74996624095 if f==118 else 105.25003375904-rho);bins=[]
  for lo,hi in [(0,.25),(.25,.5),(.5,1),(1,2),(2,5),(5,10),(10,32),(32,106)]:
   mask=(d>=lo)&(d<hi);bins.append({'distance_band_mm':[lo,hi],'triangles':int(mask.sum()),'edge_quantiles_mm':np.percentile(edges[:,mask],[0,50,95,100]).tolist() if mask.any() else []})
  shared={};ratios=[]
  for i,t in enumerate(tri):
   for a,b in [(0,1),(0,2),(1,2)]:
    k=tuple(sorted([int(t[a]),int(t[b])]))
    if k in shared:
     j=shared[k];ratios.append(max(edges[:,i].mean(),edges[:,j].mean())/min(edges[:,i].mean(),edges[:,j].mean()))
    else:shared[k]=i
  out[label][str(f)]={'triangles':len(tri),'planar_facet_max_z_error_mm':float(np.abs(xyz[:,:,2]-79).max()) if f!=117 else None, 'cylinder117_vertex_radial_error_mm':float(np.abs(np.hypot(xyz[:,:,0]-300,xyz[:,:,1])-120).max()) if f==117 else None,'aspect_longest_edge_over_min_altitude_quantiles':np.percentile(aspect,[0,50,95,99,100]).tolist(),'aspect_over_10_diagnostic_not_acceptance':int((aspect>10).sum()),'edge_quantiles_mm':np.percentile(edges,[0,1,50,99,100]).tolist(),'adjacent_tri_mean_edge_ratio_quantiles':np.percentile(ratios,[0,50,95,99,100]).tolist(),'distance_band_edge_lengths':bins}
(r/'evidence/comparison.json').write_text(json.dumps(out,indent=2));gmsh.finalize();print(json.dumps({l:{f:{k:v for k,v in d.items() if k!='distance_band_edge_lengths'} for f,d in fs.items()} for l,fs in out.items()},indent=2))

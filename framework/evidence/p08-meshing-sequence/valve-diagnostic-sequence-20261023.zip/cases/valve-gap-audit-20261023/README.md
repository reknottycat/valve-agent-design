# Read-only cylindrical gap audit

No meshgeneration. Imported unchangedoriginalSTEP and actual latest failed3Dsurface. For every CADCylinder, fit axis from sampled analyticnormals and radius from analyticUVsurfacepoints;31cylinders, maximumfitresidual3.1e-11mm. Measure fullfacet inward radial deviations in each fittedaxis frame. Candidatefilter: parallelaxes, axisline distance<1e-5mm, positive radialdifference<=2mm, axialrangesoverlap. Equalradiustrims excluded. Finiteangulartrimoverlap NOTverified, so these are screeningcandidates, not all realclearances orflowchannels.

10candidatepairs:5 with37/39/41/43/45/47 (1.5mm);64/108(1mm);132/83(1mm);101/85(1mm);103/127(.1mm). Only103/127 has negative radialenvelopeseparation; this is a possiblecrossing indicator, independently confirmed by actualPLClog and line/triangleintersection, not by boundsalone. Guide64/108passes measured20%gaperrorbudget; other pairs'budgets fail but their positive radialboundsalreadyexclude pairintersection of their currentcylindricalfacets. Do not wastecompute treating all screeningbudgetfails as actualcrossings.

For known103/127 pair, orientedCADvolume boundaries+103/-127; samplesat radii23.925,23.95,23.975 lieinsidevolume1,23.85/24.05outside. Under existingfluid_proxy semantics the local.1mm layerbelongs to modeledfluid, not excludedwall. This doesnot certify physicaldesignintent.

Proposed103/127 researchbudget .02mm perface (20%measuredgap), analyticchordlimit1.955mm atinnerR23.9; size~1mm gives margin but actualfacets MUST bechecked. Twoface area/equilateralestimate~1200–1500triangles, notguarantee ormeshacceptance. Applysize to fulluncombinedboundaryincludingseams, notselectedcurvededges. Keep existingguide4mmcontrols, unchangedCADandcoarseglobalsettings. Auditalladjacencies before anygeneration. Noadditionalcalculation performed.

Limitations: sampledanalyticfit validated byresidual, not a formalexactkernelparameterexport. Axialbounds can include trimmedregions notphysicallypresent. Noncylindricalsurfaces, conical/ringaxialclearances, fillets and other pairs are not covered. Results cannotcertifyglobalnonintersection orengineeringrelease.

import resource
resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3))
import gmsh,numpy as np,json,math
from pathlib import Path
r=Path(__file__).resolve().parent;gmsh.initialize();gmsh.model.occ.importShapes('/workspace/scratch/634aa36792d6/attachments/2618578e-bbba-4a39-81cb-899300c65163/AGR1_open_seal_omitted_proxy_main_mm.step');gmsh.model.occ.synchronize();gmsh.merge('/workspace/shared/valve-complete-boundary-volume-20261023/fresh-local-surface.msh');nt,cs,_=gmsh.model.mesh.getNodes();pos={int(t):p for t,p in zip(nt,np.array(cs).reshape(-1,3))};mapping=json.loads(Path('/workspace/shared/valve-complete-boundary-volume-20261023/evidence/geometry.json').read_text())['mapping'];families={m['gmsh_surface']:m['family'] for m in mapping};records=[]
for _,tag in gmsh.model.getEntities(2):
 if gmsh.model.getType(2,tag)!='Cylinder':continue
 lo,hi=gmsh.model.getParametrizationBounds(2,tag);uv=np.array([[u,v] for u in np.linspace(lo[0],hi[0],7) for v in [lo[1],(lo[1]+hi[1])/2,hi[1]]]);points=np.array(gmsh.model.getValue(2,tag,uv.flatten())).reshape(-1,3);normals=np.array(gmsh.model.getNormal(tag,uv.flatten())).reshape(-1,3);_,_,vh=np.linalg.svd(normals);axis=vh[-1];axis*=1 if axis[np.argmax(np.abs(axis))]>0 else -1;e1=vh[0];e2=np.cross(axis,e1);xy=np.column_stack([points@e1,points@e2]);sol=np.linalg.lstsq(np.column_stack([2*xy,np.ones(len(xy))]),np.sum(xy*xy,axis=1),rcond=None)[0];center=sol[0]*e1+sol[1]*e2;R=float(np.sqrt(sol[2]+sol[0]**2+sol[1]**2));fit=float(np.max(np.abs(np.linalg.norm(xy-sol[:2],axis=1)-R)))
 ty,ts,ns=gmsh.model.mesh.getElements(2,tag);tri=np.concatenate([n.reshape(-1,3) for t,n in zip(ty,ns) if t==2]);xyz=np.array([[pos[int(n)] for n in row] for row in tri]);p=np.stack([(xyz-center)@e1,(xyz-center)@e2],axis=2);mind=np.full(len(p),np.inf);crosses=[]
 for i,j in [(0,1),(1,2),(2,0)]:
  a=p[:,i];b=p[:,j];d=b-a;den=np.sum(d*d,axis=1);t=np.divide(-np.sum(a*d,axis=1),den,out=np.zeros(len(p)),where=den>0);t=np.clip(t,0,1);mind=np.minimum(mind,np.linalg.norm(a+t[:,None]*d,axis=1));crosses.append(a[:,0]*b[:,1]-a[:,1]*b[:,0])
 cross=np.array(crosses);mind[np.all(cross>=0,axis=0)|np.all(cross<=0,axis=0)]=0
 boundary=sorted({abs(t) for d,t in gmsh.model.getBoundary([(2,tag)],combined=False,oriented=True)})
 records.append({'face':tag,'family':families[tag],'axis':axis.tolist(),'axis_origin':center.tolist(),'radius_mm':R,'axial_range_mm':[float((points@axis).min()),float((points@axis).max())],'fit_error_mm':fit,'triangles':len(tri),'inward_error_mm':float(R-mind.min()),'outward_error_mm':float(np.linalg.norm(p,axis=2).max()-R),'uncombined_curves':boundary,'area_mm2':gmsh.model.occ.getMass(2,tag)})
pairs=[]
for i,a in enumerate(records):
 for b in records[i+1:]:
  ax=np.array(a['axis']);bx=np.array(b['axis']);delta=np.array(a['axis_origin'])-b['axis_origin'];coax=float(np.linalg.norm(delta-np.dot(delta,ax)*ax));parallel=float(np.linalg.norm(np.cross(ax,bx)));gap=abs(a['radius_mm']-b['radius_mm']);overlap=min(a['axial_range_mm'][1],b['axial_range_mm'][1])-max(a['axial_range_mm'][0],b['axial_range_mm'][0])
  if parallel>1e-7 or coax>1e-5 or not (1e-5<gap<2.000001) or overlap<=1e-6:continue
  outer,inner=(a,b) if a['radius_mm']>b['radius_mm'] else (b,a);eps=.2*gap;cmax=2*math.sqrt(2*inner['radius_mm']*eps-eps**2);target=min(4.,.55*cmax)
  pairs.append({'outer':outer['face'],'inner':inner['face'],'families':[outer['family'],inner['family']],'gap_mm':gap,'axial_overlap_mm':overlap,'pair_radial_separation_lower_bound_mm':gap-outer['inward_error_mm']-inner['outward_error_mm'],'outer_budget_pass':outer['inward_error_mm']<=eps,'inner_budget_pass':inner['inward_error_mm']<=eps,'research_budget_per_surface_mm':eps,'analytic_cmax_mm':cmax,'proposed_size_request_mm':target,'estimated_target_triangles_area_equilateral':int((a['area_mm2']+b['area_mm2'])/(math.sqrt(3)/4*target**2)),'trim_overlap_verified':False,'domain_role':'candidate_only_not_classified'})
# domain classify known failedretainer pair at exact intersection ray and overlappingz
ang=math.atan2(-21.016442391929573,11.134788577901);samples=[]
for radius in [23.85,23.925,23.95,23.975,24.05]:
 p=[300+radius*math.cos(ang),radius*math.sin(ang),105.94137790699575];samples.append({'radius_mm':radius,'xyz':p,'inside_volume1':gmsh.model.isInside(3,1,p)})
out={'cylinders':records,'candidate_pairs':pairs,'retainer_domain_samples':samples,'retainer_oriented_boundary':[list(x) for x in gmsh.model.getBoundary([(3,1)],oriented=True) if abs(x[1]) in [103,127]],'mesh_generation_executed':False,'engineering_release':False};(r/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print('cylinders',len(records),'candidatepairs',len(pairs));print(json.dumps(pairs,indent=2));print(samples);gmsh.finalize()

# Complete-boundary4mm surface trial — localized geometry gate PASSED

One fresh2D generation from unchanged originalSTEP. All original coarse global meshing settings retained. Only size callback for faces64/108 and their complete uncombined boundary set22curves is capped at4mm. Boundary and adjacency lists captured before meshing. No3D, solver or engineering release.

## Results
-163282 total triangles; complete20-face adjacency closure7191 triangles. Both provisional COST gates200000/10000 pass. Exact original6-face cost field retained but supplemented by correct complete-closure count.
-9.92909s wall,173936640bytes sampledRSS; original180s/2GiB/4GiB limits intact.
-face64 inward error over entire linear triangles0.118535844mm;face1080.124472836mm. No triangles exceed the independently chosen0.2mm/face researchbudget. This is geometry preservation evidence, not a manufacturingstandard or CFDmesh-independence criterion.
-Radial envelope separation lower bound0.881464155mm proves these two discrete cylindrical surface meshes remain disjoint. Nominal CADspacing1mm unchanged.
-All244923 unique edges incidence2; all132 faces positive-area, no zero-area triangles, noGmsh errors in capturedlog. Global selfintersection, volume quality, CFDaccuracy NOT yet established.
-CAD SHA unchanged. Non-neighborface113 has+2triangles compared with old freshbaseline; report mesh variation honestly, not exactnon-targetpreservation. All per-face counts recorded.

## Scope verification
All22uncombined boundary curves included, including opposite-orientation periodicseams164/265. Sizecallback actually changed20curves+2faces; curves266/269 already had natural size<4mm so min(lc,4) did not change them. No global size/curvature setting changed.

## Why this differs from failed earlier strategies
(1) Original32mm cylinder coarse chord sag>1mm crossed31mm cylinder.
(2) Importedmesh partialregeneration invalidateduntouchedfaces; toy reproduced it.
(3) Fresh6mm curved-edge controls removed paircrossing but missedseams.
(4) Addingseams improvedgap yet left long axialboundary transitions.
(5) Complete uncombined boundary control plus4mm request gives margin below analytic chordlimit~7mm and now passes MEASURED faceterror.
Reusable rule: mesh constraints must cover full parameter-domain boundary, including periodicseams and straight boundarysegments; callback size is a request, so verify resulting facets rather than assume errorbound.

## Review boundary
Only localized surface-geometry gate is passed. Parent must review before bounded3D. If future generate3 regenerates2D, remeasure the ACTUAL surface accompanying that volume; do not assume this savedcandidate persists. Maintain fullerror capture and savefailedcurrentmesh, not only firstexception.

Evidence: fresh-local-surface.msh; trial/monitor/verify source; rawlog; complete-boundary-audit.json; geometry.json physical/source mapping; result.json, verification.json and surface-receipt.json.

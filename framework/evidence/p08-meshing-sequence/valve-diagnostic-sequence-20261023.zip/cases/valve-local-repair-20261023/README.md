# Local repair attempt — locality gate FAILED

One2D mesh attempt, no3D. Original diagnostic archive and source CAD unchanged.

Six declared curves remeshed in1D. Despite Mesh.MeshOnlyEmpty=1,2D phase attempted non-target surface1, then performed automatic intersection splitting there. The run was interrupted through its original tool session; exit130. No valid repaired surface, error measure, radial clearance, or post-run preservation result is claimed. Monitor peak RSS/final receipt are unavailable because interruption preceded its normal receipt write. Configured hard guards were180s/2GiB RSS/4GiB address.

A separate clear-only in-memory preflight, with ZERO generate calls, verified exactly the six declared surfaces and six curves change before meshing. Thus the violation occurs in the meshing stage, not an overbroad explicit clear list. The exact internal invalidation behavior has not been source-code proven; do not label this as a verified Gmsh defect.

Read-only alternative research: official Gmsh tutorial t5 describes hiding all entities and showing a subset with Mesh.MeshOnlyVisible=1; option documentation labels it experimental. This can be considered as an explicit second locality control, but cannot be promised correct without bounded runtime validation. Preserve per-entity pre/post hashes and add supervisor detection of any meshing log outside the allowlist, with graceful termination. Reconstruct missing parametric coordinates on imported mesh nodes may also require evaluation. Neither alternative has been executed.

Official references:
https://gmsh.info/doc/texinfo/gmsh.html#t5
https://gmsh.info/doc/texinfo/gmsh.html#index-Mesh_002eMeshOnlyVisible
https://gmsh.info/doc/texinfo/gmsh.html#index-Mesh_002eMeshOnlyEmpty

Evidence: surface.log, before-fingerprints.json, clear-only-preflight.json, failure-receipt.json; scripts retained for auditing, not automatic rerun.

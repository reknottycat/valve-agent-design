# Seam-aware scoped surface trial — budget still FAILED, pairwise separation improved

One fresh2D generation from unchanged originalSTEP. Previous global mesh settings retained. Callback caps6mm on faces64/108 and the original six curves plus parameter seams164/265. No3D or CFD. Resource gates unchanged. This is a distinct correction prompted by the actual worst-facet entity classification, not blind global refinement.

Uncombined-boundary audit confirms exactly seam164 on64 and265 on108 cancel from combined boundary, with opposite signed occurrences. Callback modification list is exactly those eight curves and two faces (result.json).

Measured159428triangles, 3105 in six-face closure; cost gates200000/10000 pass. Wall9.92986s, sampledRSS173891584bytes. Source hash unchanged. All239142 unique edges incidence2. Per-face areas positive; this is not proof of global absence of selfintersection.

Full linear-facet radial envelope analysis (including interiors) gives:
- face64 inward error0.560161358mm;73 facets over0.2mm
- face108 inward error0.420412600mm;74 facets over0.2mm
- minimum radial envelope separation0.439838642mm, so pairwise nonintersection proven for these two cylindrical surface meshes.

Status: intended0.2mm/face researchbudget FAILS. No3D qualification claimed. Pairwise gap improvement is real but not completion of surface validation.

Worst facets moved from seams to uncontrolled axial boundary curves166 and261. Thus controlling curved edges plus periodic seams alone is insufficient for this isotropic triangular surface mesher: long boundary segments can induce long diagonals in adjacent triangles. Proposed next approach (not executed): audit/control ALL uncombined boundary entities of both targetfaces with local size6mm, retaining coarse settings elsewhere. This would widen explicit local boundary control and could change neighboring face meshes; list adjacency and costs before generation. Do not silently weaken0.2mm gate or refine globally.

Reusable lesson: discover boundary loops with combined=False when collecting meshing constraints; seam cancellation is mathematically valid for oriented boundary algebra but inappropriate for parameter-domain meshing constraint coverage. Target mesh size is a request, not a verified maximum chord error. Test actual facets and their boundary classification.

Evidence: trial.py, monitor.py, verify.py; evidence/boundary-audit.json, result.json, verification.json, surface-receipt.json, rawsurface.log; actual fresh-local-surface.msh. No installed-package changes or source geometry changes.

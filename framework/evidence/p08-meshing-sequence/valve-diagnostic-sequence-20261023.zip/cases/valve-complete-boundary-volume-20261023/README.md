# Bounded3D check after guide repair — FAILED at a different retainer boundary

One fresh3D attempt, unchanged CAD and same complete-boundary4mm guide controls used in accepted localized2D geometry check. AbortOnError0 captures full diagnostic context; processreturn0 is NOTsuccess. No optimization retry, additional refinement or flow solver.

Wall12.84389s, sampledRSS385667072bytes; configured180s/2GiB/4GiB caps nothit. Three meshing errors, zero tetrahedra after savedmesh readback. Actual surface saved in fresh-local-surface.msh (contains no3D elements despite filename reuse);163282triangles.

Prior guidefaces64/108 remain geometry-qualified on THIS actual3D failure surface: max inwarderrors0.118535844/0.124472835mm, gap radial lowerbound0.881464155mm. Thus the original identified clash is not recurring.

New failure: source/Gmsh face103 segmentnodes1263/1275 intersects face127 tri27573/27574/27585; both retainerfamily. Fullerror intersection(311.135,-21.0164,105.941), independent exact linear solve(311.134788578,-21.016442392,105.941377907)mm. Segmentparameter0.927899048 and strictlypositive triangle barycentric weights prove an interior crossing.

Read-only unchanged CAD projection confirms both cylinders, radii24 and23.9mm, localspacing0.1mm. Intersection lies0.216090156mm from outerCAD and0.116090156mm from innerCAD. This is another locally underresolveddiscreteboundary issue, NOT proof of incorrect mechanicaldesign orsoftwarebug. Sourcevolume/domainintent around newpair notyetclassified.

Next proposed work NOTEXECUTED: generalize measuredgap-driven errorbudget and completeboundary+seam coverage, audit narrowcylindricalregions before furthermeshing, rather than chasingoneintersection per3Dattempt. Existing0.2mm guidebudget must NOTbeapplied blindly to0.1mmretainerspacing. No newmesh authorization inferred.

Evidence: raw volume.log, volume-receipt.json, source/physical mappinggeometry.json, actualmesh, verification.json onactualsurface, conflict-readback.json, analytic-local-check.json, volume-readback.json showingzeroelements. OriginalSTEP hash unchanged.

# Disposable Gmsh locality API test — preservation FAILED

Synthetic two disjoint1x1 plane rectangles only; no P08 import or generation. Official Gmsh4.15.2, existing installed vendor, no installation. Runtime0.183s, sampled peak60878848bytes; limits30s/256MiB.

Lifecycle: make two planes, coarse2D mesh, save BREP+MSH, clear model, reload BREP+MSH, fingerprint both mesh sets; clear only targetface1 andcurves1-4; hide all/show target recursively; MeshOnlyVisible=1 and MeshOnlyEmpty=1; reduce size and generate2D.

Result: log shows only targetcurves1-4 andsurface1 generated. Thus visibility limits generation in this toy. However non-targetface2 triangles disappear, with fingerprint exactly SHA256(repr([]))=4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945. Non-target preservation FAILED. The supervisor's immediate non-target-meshing detector did not fire, because destruction occurred without meshinglog for that entity. This demonstrates why post-run fingerprints are mandatory in addition to monitoring.

Do not deploy this option-only strategy on actualP08. Next proposed route: isolate six-face CAD/mesh closure into a separate temporary local model, preserve interface curves to frozen neighbors, mesh only the submodel, and explicitly assemble its nodes/elements back into a copy of the original full mesh, preserving shared interface IDs/coordinates and all original non-target entities. Alternatively cache/reinsert untouched mesh data after Gmsh invalidation; that needs validation of node classification/parametric coordinates and topology. Either route requires another tiny synthetic interface-conformity test before actualP08. Neither implemented or run here.

Official docs read before test: https://gmsh.info/doc/texinfo/gmsh.html#t5 demonstrates MeshOnlyVisible; https://gmsh.info/doc/texinfo/gmsh.html#index-Mesh_002eMeshOnlyVisible marks it experimental. Existing test establishes behavior only for this exact import/lifecycle/version.

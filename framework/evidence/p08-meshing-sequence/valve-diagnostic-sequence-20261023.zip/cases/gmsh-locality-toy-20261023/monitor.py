import os,sys,time,signal,subprocess,json,re
from pathlib import Path
r=Path(__file__).resolve().parent;st=time.monotonic();peak=0;reason=None
with (r/'log.txt').open('w') as f:
 p=subprocess.Popen([sys.executable,str(r/'toy.py')],env=dict(os.environ,PYTHONPATH='/workspace/shared/valve-gmsh-trial-20261023/vendor',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  try:peak=max(peak,int(next(x.split()[1] for x in Path(f'/proc/{p.pid}/status').read_text().splitlines() if x.startswith('VmRSS:')))*1024)
  except:pass
  text=(r/'log.txt').read_text()
  if 'LOCAL_STAGE_START' in text:
   local=text.split('LOCAL_STAGE_START',1)[1];allow=json.loads((r/'allowlist.json').read_text())
   for kind,n in re.findall(r'Meshing (surface|curve) (\d+)',local):
    if int(n) not in allow['surfaces' if kind=='surface' else 'curves']:reason='non_target_meshing';break
  if time.monotonic()-st>30:reason='wall30s'
  if peak>256*1024**2:reason='rss256MiB'
  if reason:
   os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(.02)
 rc=p.wait()
(r/'receipt.json').write_text(json.dumps({'returncode':rc,'stop_reason':reason,'elapsed_s':time.monotonic()-st,'peak_rss_bytes':peak},indent=2));print((r/'receipt.json').read_text())

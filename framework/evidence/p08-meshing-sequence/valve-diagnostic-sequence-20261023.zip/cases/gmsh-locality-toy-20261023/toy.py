import resource
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
import gmsh,json,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
def fp():
 nt,cs,_=gmsh.model.mesh.getNodes();p={int(t):tuple(cs[i*3:i*3+3]) for i,t in enumerate(nt)};o={}
 for d,t in gmsh.model.getEntities():
  if d not in (1,2):continue
  types,_,ns=gmsh.model.mesh.getElements(d,t);els=[]
  for typ,nds in zip(types,ns):
   k=gmsh.model.mesh.getElementProperties(int(typ))[3]
   for i in range(0,len(nds),k):els.append((int(typ),tuple(sorted(p[int(n)] for n in nds[i:i+k]))))
  o[f'{d}:{t}']=hashlib.sha256(repr(sorted(els)).encode()).hexdigest()
 return o
gmsh.initialize();gmsh.option.setNumber('General.NumThreads',1)
gmsh.model.occ.addRectangle(0,0,0,1,1,1);gmsh.model.occ.addRectangle(3,0,0,1,1,2);gmsh.model.occ.synchronize();gmsh.option.setNumber('Mesh.MeshSizeMax',.35);gmsh.option.setNumber('Mesh.MeshSizeMin',.35);gmsh.model.mesh.generate(2);gmsh.option.setNumber('Mesh.SaveAll',1);gmsh.write(str(r/'toy.brep'));gmsh.write(str(r/'toy.msh'));gmsh.clear();gmsh.open(str(r/'toy.brep'));gmsh.merge(str(r/'toy.msh'))
pre=fp();edges={t for d,t in gmsh.model.getBoundary([(2,1)],oriented=False)}
(r/'allowlist.json').write_text(json.dumps({'surfaces':[1],'curves':list(edges)}));gmsh.model.mesh.clear([(2,1)]);gmsh.model.mesh.clear([(1,t) for t in edges]);gmsh.model.setVisibility(gmsh.model.getEntities(),0);gmsh.model.setVisibility([(2,1)],1,recursive=True);gmsh.option.setNumber('Mesh.MeshOnlyVisible',1);gmsh.option.setNumber('Mesh.MeshOnlyEmpty',1);gmsh.option.setNumber('Mesh.MeshSizeMin',.15);gmsh.option.setNumber('Mesh.MeshSizeMax',.15)
print('LOCAL_STAGE_START',flush=True);gmsh.logger.start();gmsh.model.mesh.generate(2);logs=gmsh.logger.get();post=fp();changed=[k for k in pre if pre[k]!=post[k]];bad=[k for k in changed if k!='2:1' and k not in {f'1:{e}' for e in edges}];result={'changed':changed,'unexpected_changes':bad,'before':pre,'after':post,'logs':logs,'non_target_preserved':not bad,'synthetic_only':True,'actual_P08_generated':False};(r/'result.json').write_text(json.dumps(result,indent=2)+'\n');gmsh.write(str(r/'toy-local.msh'));gmsh.finalize()

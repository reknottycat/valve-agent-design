import gmsh,json
from pathlib import Path
r=Path(__file__).resolve().parent;gmsh.initialize();gmsh.model.occ.importShapes('/workspace/scratch/634aa36792d6/attachments/2618578e-bbba-4a39-81cb-899300c65163/AGR1_open_seal_omitted_proxy_main_mm.step');gmsh.model.occ.synchronize();out={}
for sid in [64,108]:out[sid]={'uncombined_boundary':gmsh.model.getBoundary([(2,sid)],combined=False,oriented=True),'combined_boundary':gmsh.model.getBoundary([(2,sid)],combined=True,oriented=True)}
for edge in [164,265]:out[f'edge{edge}']={'type':gmsh.model.getType(1,edge),'upward_adjacency':gmsh.model.getAdjacencies(1,edge)[0].tolist()}
(r/'evidence/seam-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out));gmsh.finalize()

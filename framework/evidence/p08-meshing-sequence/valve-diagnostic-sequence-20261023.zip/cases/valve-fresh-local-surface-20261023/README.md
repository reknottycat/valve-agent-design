# Fresh locally controlled surface trial — partial geometric improvement, budget NOT PASSED

## Strategy change
Exact preservation of previous non-target triangles was an optional implementation strategy, not the user's requirement. Prior import/clear/rebuild strategy invalidated untouched2D elements, including with MeshOnlyVisible in a toy. Instead this trial starts unchanged originalSTEP and generates a fresh surface with all original coarse global parameters. The only sizing changes are callback cap6mm on faces64/108 and curves161/165/253/254/258/264. No CAD change, importedmesh, globalrefinement,3D mesh, or flow solver. Prior failures remain preserved separately.

## Measured outcome
159312 triangles; six-face local closure 2989 triangles. Cost gates200000/10000 passed. Wall9.9365s, sampledRSS173711360bytes. Source SHA unchanged.

Exact linear triangle radial minimization includes triangle interiors and edges, not only nodes:
- face64 max inward deviation0.845098460mm (133 triangles exceed0.2mm budget)
- face108 max inward deviation0.457308007mm (102 triangles exceed0.2mm budget)
- radial envelope separation lower bound0.154901539mm>0 proves these two complete discretized cylindrical surfaces cannot intersect each other.
Thus the identified pairwise crossing is removed, but intended0.2mm geometric research budget has NOT passed. No3D authorization inferred.

All238968 unique surface edges have incidence2. All132 faces have positive-area triangles (see per-face minimum areas), but this does not prove absence of selfintersection elsewhere or full geometry conformity. CAD face mapping unchanged by design; per-face mesh counts are retained. Uncontrolled-face count changes against original fresh baseline:81:-6,113:+2,119:+2. No exact frozen-mesh claim.

## Remaining defect localized to parameter seams
Worst face64 triangle touches node826 on CADcurve164; face108 worst touches node1248 on curve265. Uncombined CAD boundaries show+164/-164 and+265/-265 respectively; default combined boundary cancels these parameter seams. Both are Line entities adjacent only to their own cylindrical face. This proves the prior boundary enumeration omitted seam entities; it is a plausible cause of coarse seam-adjacent triangles, not a softwarebug claim.

Proposed next refinement of method, NOT EXECUTED: include seam164/265 in the same local size callback and inspect all uncombined boundary entities. Their adjacency implies no new external neighbor closure is required for these two seam curves. Re-measure actual facets; target size alone is not a maximum edge guarantee. Stop before3D until reviewed.

Evidence: result.json, verification.json (worst triangle coordinates/entity labels included), seam-check.json, surface-receipt.json, rawsurface.log, fresh-local-surface.msh. Verify script computes cylindrical inward errors over projected triangular convex hulls, and max radial radius at vertices. Claims are specific to radial envelopes of this cylindricalpair, not generic certifiedHausdorff distances.

#include "fvCFD.H"
#include "directionMixedFvPatchFields.H"
#include "smoothSolver.H"
#include "HeldContext.H"
#include "heldOperatorSmoothSolver.C"
#include "MomentumBalanceProbe.H"
#include <cassert>
using namespace Foam;
class InspectMatrix:public fvVectorMatrix {
 public: explicit InspectMatrix(const fvVectorMatrix& a):fvVectorMatrix(a){}
 using fvVectorMatrix::addBoundaryDiag;
 using fvVectorMatrix::addBoundarySource;
};
std::string matrixHash(const fvVectorMatrix& a){HeldHash h;h.field(a.diag());h.field(a.lower());h.field(a.upper());h.field(a.source());h.patches(a.internalCoeffs());h.patches(a.boundaryCoeffs());return h.done();}
std::string fieldHash(const volVectorField& u){HeldHash h;h.field(u.primitiveField());forAll(u.boundaryField(),p)h.field(u.boundaryField()[p]);return h.done();}
int main(int argc,char** argv){
 #include "setRootCase.H"
 #include "createTime.H"
 #include "createMesh.H"
 assert(mesh.nCells()==2);const label timeIndex=runTime.timeIndex();const scalar time=runTime.value();
 surfaceScalarField phi(IOobject("phi",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE),mesh);
 volScalarField p(IOobject("p",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE),mesh);
 volVectorField U(IOobject("U",runTime.timeName(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE),mesh);
 U.correctBoundaryConditions();
 volVectorField Uref(IOobject("Uref",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::NO_WRITE),U);
 Uref.correctBoundaryConditions();assert(fieldHash(U)==fieldHash(Uref));
 const label outlet=mesh.boundaryMesh().findPatchID("outlet");assert(outlet>=0);
 const directionMixedFvPatchVectorField& mixed=refCast<const directionMixedFvPatchVectorField>(U.boundaryField()[outlet]);
 const bool backflow=phi.boundaryField()[outlet][0]<0;
 const scalar fraction=tr(mixed.valueFraction()[0]);assert(fraction==(backflow?2.0:0.0));
 Info().precision(17);Info<<"FIXTURE boundary pressureInletOutletVelocity backflow "<<backflow<<" fractionTrace "<<fraction<<" tangential "<<mixed.refValue()[0]<<nl;
 dimensionedScalar nu("nu",dimViscosity,0.15),rate("rate",dimless/dimTime,0.3);
 tmp<fvVectorMatrix> tA(fvm::div(phi,U)-fvm::laplacian(nu,U)+fvm::Sp(rate,U));
 tmp<fvVectorMatrix> tR(fvm::div(phi,Uref)-fvm::laplacian(nu,Uref)+fvm::Sp(rate,Uref));
 fvVectorMatrix& A=tA.ref();fvVectorMatrix& R=tR.ref();assert(matrixHash(A)==matrixHash(R));
 MomentumBalanceProbe mbp(mesh,U,1,true);mbp.raw(A);A.relax(0.7);R.relax(0.7);mbp.relaxed(A);mbp.constrained(A);assert(matrixHash(A)==matrixHash(R));
 volVectorField rhs(IOobject("rhs",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::NO_WRITE),mesh,dimensionedVector("acceleration",dimVelocity/dimTime,vector(0.01,0.02,0.03)));
 mbp.beforeSolve(U,rhs);
 tmp<fvVectorMatrix> tEq(A==rhs),tRef(R==rhs);
 fvVectorMatrix& eq=tEq.ref();fvVectorMatrix& ref=tRef.ref();assert(matrixHash(eq)==matrixHash(ref));
 const std::string eqBefore=matrixHash(eq),refBefore=matrixHash(ref);
 const vectorField initial(U.primitiveField());
 InspectMatrix inspect(eq);vectorField completeSource(eq.source());inspect.addBoundarySource(completeSource);
 dictionary controls(A.solverDict());
 const SolverPerformance<vector> reference=ref.solve(controls);
 assert(matrixHash(ref)==refBefore); // diagonal removed/restored by actual fvMatrix solve.
 const std::string expectedNormal=fieldHash(Uref);
 HeldContext held(mesh,p,phi);mbp.attachHeld(held);const std::string physical=held.physicalHash();
 controls.set("solver",word("heldOperatorSmoothSolver"));
 const SolverPerformance<vector> candidate=eq.solve(controls);
 assert(matrixHash(eq)==eqBefore);held.verifyComplete();assert(fieldHash(U)==expectedNormal);
 assert(candidate.initialResidual()==reference.initialResidual());assert(candidate.finalResidual()==reference.finalResidual());assert(candidate.nIterations()==reference.nIterations());assert(candidate.solverName()==reference.solverName());
 assert(candidate.converged()==reference.converged());assert(candidate.singular()==reference.singular());
 // Independent actual-fvMatrix boundary augmentation and native one-sweep reference.
 const scalarField savedDiag(inspect.diag());
 for(direction c=0;c<3;++c){
  inspect.diag()=savedDiag;inspect.addBoundaryDiag(inspect.diag(),c);
  scalarField source(completeSource.component(c));
  FieldField<Field,scalar> bc(eq.boundaryCoeffs().component(c)),ic(eq.internalCoeffs().component(c));
  lduInterfaceFieldPtrsList interfaces=U.boundaryField().scalarInterfaces();
  dictionary cfg(controls);cfg.set("solver",word("smoothSolver"));
  scalarField start(initial.component(c)),aStart(mesh.nCells()),scratch(mesh.nCells());
  smoothSolver native("U",inspect,bc,ic,interfaces,cfg);inspect.Amul(aStart,start,bc,interfaces,c);
  const scalar normalizer=native.normFactor(start,source,aStart,scratch);assert(normalizer==held.capturedNorm[c]);
  scalarField q(Uref.primitiveField().component(c));autoPtr<lduMatrix::smoother> smoother=lduMatrix::smoother::New("U",inspect,bc,ic,interfaces,cfg);smoother->smooth(q,source,c,1);
  assert(q==held.shadow.component(c)());
 }
 mbp.finish(U);mbp.heldFinish(U,held.shadow);
 assert(held.physicalHash()==physical);assert(runTime.timeIndex()==timeIndex&&runTime.value()==time);
 assert(fieldHash(U)==expectedNormal);
 Info<<"FV_MESH_BC_LIFECYCLE_PASS cells 2 backflow "<<backflow<<" identical_raw_relaxed_equations actual_boundary_add_restore normal_full_U_and_performance_exact shadow_reference_exact no_p_phi_time_advancement"<<nl;
 return 0;
}

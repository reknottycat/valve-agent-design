from pathlib import Path
import os,resource,subprocess,json,time,sys,hashlib
B=Path(__file__).parent;mode=sys.argv[1];assert mode in ('mesh','outflow','backflow')
result=B/(mode+'-result.json');assert not result.exists(),'consumed attempt; no automatic retry'
case=B/('mesh-case' if mode=='mesh' else mode+'-case')
exe=Path('/workspace/shared/valve-openfoam-quality-20261023/root/usr/bin/blockMesh') if mode=='mesh' else B/'bin/fixture'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before={str(p.relative_to(case)):sha(p) for p in case.rglob('*') if p.is_file()}
expected=json.loads((B/(mode+'-frozen-inputs.json')).read_text());assert before==expected,'case drift'
pins=json.loads((B/'execution-pins.json').read_text());assert all(sha(p)==h for p,h in pins.items()),'source/binary/runner drift'
(B/(mode+'-inputs-before.json')).write_text(json.dumps(before,indent=2)+'\n')
def limits():
 os.setsid();os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));resource.setrlimit(resource.RLIMIT_CPU,(5,5));resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(1048576,1048576))
env={**os.environ,'WM_PROJECT_DIR':'/workspace/shared/valve-openfoam-quality-20261023/root/usr/share/openfoam','FOAM_ETC':'/workspace/shared/valve-openfoam-quality-20261023/root/usr/share/openfoam/etc','LD_LIBRARY_PATH':'/workspace/shared/valve-openfoam-quality-20261023/root/usr/lib/dummy:/workspace/shared/valve-openfoam-quality-20261023/root/usr/lib','OMP_NUM_THREADS':'1','HOME':str(B),'TMPDIR':str(B/'tmp')}
record=dict(mode=mode,exe=str(exe),exe_sha256=sha(exe),case=str(case),started=True,closed=False,limits=dict(AS=268435456,CPU=5,wall=10,output=1048576,threads=1,core=0))
with result.open('x') as latch: latch.write(json.dumps(record,indent=2)+'\n')
t=time.monotonic()
with (B/(mode+'.log')).open('w') as log:
 p=subprocess.Popen([str(exe),'-case',str(case)],env=env,cwd=B,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
 try:rc=p.wait(timeout=10);timeout=False
 except subprocess.TimeoutExpired:os.killpg(p.pid,9);rc=p.wait();timeout=True
record.update(exit=rc,timeout=timeout,wall=time.monotonic()-t,peak_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,closed=True,original_inputs_unchanged=all(sha(case/p)==h for p,h in before.items()),all_case_files={str(p.relative_to(case)):sha(p) for p in case.rglob('*') if p.is_file()})
record['pinned_sources_unchanged']=all(sha(p)==h for p,h in pins.items())
record['case_file_set_unchanged']=set(record['all_case_files'])==set(before)
result.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='all_case_files'},indent=2));raise SystemExit(rc!=0 or not record['pinned_sources_unchanged'] or not record['original_inputs_unchanged'] or (mode!='mesh' and not record['case_file_set_unchanged']))

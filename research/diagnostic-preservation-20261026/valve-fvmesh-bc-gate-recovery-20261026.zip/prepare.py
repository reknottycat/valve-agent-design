from pathlib import Path
import json
B=Path(__file__).parent;case=B/'mesh-case';(case/'system').mkdir(parents=True);(case/'constant').mkdir();(case/'0').mkdir()
header=lambda cls,obj:f'FoamFile {{version 2.0;format ascii;class {cls};object {obj};}}\n'
(case/'system/blockMeshDict').write_text(header('dictionary','blockMeshDict')+'''convertToMeters 1;
vertices ((0 0 0)(2 0 0)(2 1 0)(0 1 0)(0 0 1)(2 0 1)(2 1 1)(0 1 1));
blocks (hex (0 1 2 3 4 5 6 7) (2 1 1) simpleGrading (1 1 1));
edges ();
boundary (
inlet { type patch; faces ((0 4 7 3)); }
outlet { type patch; faces ((1 2 6 5)); }
walls { type wall; faces ((0 1 5 4)(3 7 6 2)(0 3 2 1)(4 5 6 7)); }
);
mergePatchPairs ();
''')
(case/'system/controlDict').write_text(header('dictionary','controlDict')+'''application heldFvMeshFixture;startFrom startTime;startTime 0;stopAt endTime;endTime 0;deltaT 1;writeControl timeStep;writeInterval 1;runTimeModifiable false;
functions {};
heldOperatorEnabled true;
momentumBalanceProbe {enabled true;targetOuter 1;maxObserverBytes 536870912;selectedCells ();}
''')
(case/'system/fvSchemes').write_text(header('dictionary','fvSchemes')+'''ddtSchemes { default steadyState; }
gradSchemes { default Gauss linear; }
divSchemes { default Gauss upwind; }
laplacianSchemes { default Gauss linear corrected; }
interpolationSchemes { default linear; }
snGradSchemes { default corrected; }
fluxRequired {default no;}
''')
(case/'system/fvSolution').write_text(header('dictionary','fvSolution')+'''solvers { "(U|Uref)" { solver smoothSolver; smoother symGaussSeidel; tolerance 1e-14; relTol 0; minIter 3; maxIter 3; nSweeps 1; } }
relaxationFactors { equations { "(U|Uref)" 0.7; } }
''')
(case/'0/U').write_text(header('volVectorField','U')+'''dimensions [0 1 -1 0 0 0 0];internalField uniform (0.2 0.1 -0.1);
boundaryField {
inlet {type fixedValue;value uniform (1 0.2 0.3);}
outlet {type pressureInletOutletVelocity;phi phi;tangentialVelocity uniform (0 0.4 0.5);value uniform (0.2 0.1 -0.1);}
walls {type noSlip;}
}
''')
(case/'0/p').write_text(header('volScalarField','p')+'''dimensions [0 2 -2 0 0 0 0];internalField uniform 0.1;
boundaryField {inlet {type zeroGradient;} outlet {type fixedValue;value uniform 0;} walls {type zeroGradient;}}
''')
(case/'0/phi').write_text(header('surfaceScalarField','phi')+'''dimensions [0 3 -1 0 0 0 0];internalField uniform 0.25;
boundaryField {inlet {type calculated;value uniform -0.25;} outlet {type calculated;value uniform 0.25;} walls {type calculated;value uniform 0;}}
''')

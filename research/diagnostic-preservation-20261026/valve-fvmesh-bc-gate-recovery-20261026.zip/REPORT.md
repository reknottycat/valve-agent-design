# Actual fvMesh / noncoupled BC lifecycle slice — verified synthetic fixture

2026-10-26 04:06 UTC. **New actual native evidence beyond the earlier manually assembled LDU test. No real-valve run or engineering release.**

## What actually ran
One pinned blockMesh invocation generated a full-three-dimensional **2-cell / 11-face / 1-internal-face** hex mesh. Two pre-frozen variants then ran once each: outlet phi +0.25 (outflow) and −0.25 (backflow). Their 12-file manifests differ only in that outlet phi value. These are synthetic stress fixtures, not new valve physical assumptions, real operating points or a mass-consistent flow model.

The native fixture loads real fvMesh, U/p/phi objects and actual boundary classes: inlet fixedValue, walls noSlip, outlet pressureInletOutletVelocity with deliberately nonzero tangentialVelocity (0,0.4,0.5). Native directionMixed valueFraction trace is exactly 0 for outflow and 2 for backflow. This exercises both signs of the actual neg(phi)*(I−nn) boundary path.

The fixture assembles actual fvm::div(phi,U) − fvm::laplacian(nu,U) + fvm::Sp(rate,U), relaxes at 0.7 and applies manufactured constant acceleration RHS (0.01,0.02,0.03). It does **not** evaluate −grad(p), solve pEqn, advance phi/time, reproduce valve geometry or validate momentum physics. All three vector components are active.

## Results
| Invocation | Exit | Wall seconds | Peak RSS KiB |
|---|---:|---:|---:|
| blockMesh, once | 0 | 0.115630 | 56676 |
| Outflow fixture, once | 0 | 0.115375 | 94480 |
| Backflow fixture, once | 0 | 0.115618 | 94044 |

Every invocation retained predeclared **256 MiB AS / 5 CPU seconds / 10 wall seconds / one CPU / 1 MiB file/output cap / core 0**. There was no native retry or budget increase. Final fixture compiled under the separate existing 2 GiB / 80 CPU / 90 wall build ceiling: exit 0, 15.413 s wall, 15.372 s CPU, 670116 KiB peak.

Assertions actually exercised in both variants:
- Original Uref and candidate U start with identical complete internal/boundary values. Independently assembled raw, relaxed and complete-RHS matrix coefficients/source/boundary arrays hash identically.
- Actual fvMatrix::solve adds component boundary diagonal/source, solves, restores diagonal, and calls correctBoundaryConditions. Whole equation hashes before/after each normal solve are exactly unchanged.
- Candidate normal internal AND all boundary U values match original solver exactly. Solver name, iterations, initial/final component residuals, convergence and singularity flags match exactly.
- A fixture-only subclass exposes the actual protected addBoundarySource/addBoundaryDiag methods. A separately instantiated native smoother on that actual augmented component system reproduces each shadow's one additional sweep exactly; original-entry native normalization matches exactly.
- Candidate HeldContext physical p/phi/V identity is unchanged across its bracket. Whole fixture time index/value is unchanged; source contains no pEqn/phi-update/time-loop path. The reference solve occurs before the candidate physical hash bracket; no additional measured pre-reference physical hash claim is made.
- Both 12-file case trees and all 14 execution pins remained unchanged. Original prior frozen candidate's 25 entries remain unchanged. The earlier passed 3-cell LDU test and 108 formula checks were not rerun.

Native versus frozen reconstructed arithmetic is **not bit-identical**: max component diagonal difference is 8.881784197001252e−16 (outflow), 4.440892098500626e−16 (backflow). Largest absolute normalized residual-link difference is 1.0842021724855044e−15. Differences remain recorded with tolerance_NOT_ASSIGNED; they are not silently zeroed, certified as an error bound or assigned an engineering acceptance threshold.

## Artifact identity and retained failures
Fixture binary SHA256: fccac312ce32bf900f2070ef4f39496fad449b3cd38d645032171740bfafbd71.
Execution-pins SHA256: a9464fdc2aacf6bc48f79ade71f2d998e85f22912626b902eb69d4cfab0c6b93.
Outflow input manifest: 48e955975c7f6636252233994e63874f97ee4989c95f322bafee3b6d67aac63d.
Backflow input manifest: c122e9554e5ba2b13f698193b4d63e810bf77e622b9d85f30e9f5859cfc4338e.

Build1 failed on guessed directionMixed header spelling; corrected to the actual SDK alias header. Build2 failed on Info.precision rather than Info().precision; corrected to pinned API syntax. Both logs/source versions remain. Independent pre-execution review caught a string/Path hash-helper mismatch; fixed and tested before consuming any native latch, old wrapper retained. These are fixture/API preparation defects, not flow divergence, permission denial or native failed attempts.

## What this closes — and what remains
This closes the **tested two-cell, two-sign, actual fvMesh/noncoupled pressureInletOutletVelocity lifecycle slice**. It supports the diagnostic's implementation on this path; it does not cover every mesh/BC state, actual pressure forcing, all failure paths, physical BC adequacy or whole-process fit on the real valve.

Still HOLD the 759760-cell case. Next gates are strict HOP parser/phase/count/finite/unit verification and failure-path tests; pinned complete runtime mappings including libcrypto; a new exclusive case/latch and disabled supervisor preserving original limits and ordinary-output hashes; independent exact-digest review and separate one-attempt authorization. The real-case caps remain 2 GiB aggregate / 44 CPU/inner-wall / 45 outer-wall seconds / one CPU; no increase proposed. p/phi physical-drift rejection fault injection is not established merely by the observed unchanged hashes here.

R1 unchanged/BLOCKED; real product Q/DeltaP/K null. No original physical input change, large solve, installation, security change, GitHub/CNB attempt or publication. Linear remains In Progress.

# Independent actual-fvMesh lifecycle fixture review
2026-10-26 04:04 UTC. Read-only reviewer; no utility/solver execution and no candidate edits.

## Scope and prior evidence
ZHE-91 latest comment 273dc4e2-ae98-46bd-994c-d59542afd4d6 (03:44:56 UTC) remains compiled + 3-cell LDU evidence, explicitly missing actual fvMesh boundary lifecycle. This two-cell fixture addresses that gap, not duplicate representative valve work. Initial Pages lookup of shorthand ZHE91 failed; parent supplied correct Linear issue. Linear latest comments read successfully; get_agent_context returned tool-not-found, no retry.

Actual checkpoint15 U has inlet fixedValue, outlet pressureInletOutletVelocity, walls noSlip. Pinned native pressureInletOutletVelocityFvPatchVectorField.C updateCoeffs uses neg(phi)*(I−nn), confirming positive/outflow and negative/backflow exercise distinct native branches. Nonzero tangential velocity in fixture is an intentional stress input, not a claim of identical real-case data.

## Pre-execution source and geometry review
Inspected `valve-held-fvmesh-fixture-20261026/fixture.C`, PROTOCOL.json, all field/system inputs, build command and run_tiny.py. Exactly two full-3D hexahedral cells, no empty/wedge suppression. Actual fvMesh and fvVectorMatrix are used. Separate U/Uref assemblies are required to match exactly at raw, relaxed and complete RHS stages. Reference and held solves compare full internal+boundary normal U and solver performance; matrix hashes check boundary diagonal restoration. Independent native addBoundarySource/addBoundaryDiag and one symGS sweep supply the shadow/normFactor reference. Actual p/phi/volumes are hashed and time values remain fixed. No pEqn, time loop or phi update appears.

The RHS is manufactured uniform acceleration, not -grad(p); this is an algebraic/BC lifecycle test, not pressure-coupled flow validation. Actual phi signs are fixed independently, not a physically converged flux solution.

Original 25-entry compiled candidate freeze still matches. Fixture compile failures (header alias, Info precision API) are explained source errors and retained; no numerical test was run for those attempts. Third build reports success. No assertions-disabled compile flag seen.

## Wrapper review and scoped permission
Found and corrected through writer before any execution: SHA helper called .read_bytes() on string manifest keys. Writer changed to Path(p).read_bytes(), preserved old wrapper and repinned. Independently verified all14 execution pins and initial mesh input hashes; no result latch existed.

Reviewed execution manifest SHA256 `a9464fdc2aacf6bc48f79ade71f2d998e85f22912626b902eb69d4cfab0c6b93`; fixture binary `fccac312ce32bf900f2070ef4f39496fad449b3cd38d645032171740bfafbd71`; protocol `6842ad872cf84427a74d73b411cfd7de6faa80e2b093376b8be1c936aeade554`.

APPROVE tiny scope only: one pinned blockMesh generation, then one outflow and one backflow fixture invocation after separate input freeze; variants differ only predeclared outlet phi sign. Each native invocation: 256MiB AS,5CPU s,10wall s,one CPU,1MiB output,zero core,exclusive result latch, no automatic retries. Post-run input/source hashes are required. This is not a full runtime mapping supervisor or real-valve authorization. Unexpected failure/cap stops dependent work for diagnosis; no budget expansion.

Await terminal artifacts and final frozen manifest before approving result claim. Real 759760-cell case remains HOLD, and R1/product-value status remains unchanged.

## Final independent verification, 04:08 UTC
Verified all75 entries of `frozen-fixture.json`, SHA256 `cf30400ded353446be9e489455c1af8dae4dd73e9739c8fa023ff8ebdcc73608`; no mismatches. Separately verified both12-entry input manifests: outflow `48e955975c7f6636252233994e63874f97ee4989c95f322bafee3b6d67aac63d`, backflow `c122e9554e5ba2b13f698193b4d63e810bf77e622b9d85f30e9f5859cfc4338e`; only outlet phi differs.

Read terminal native logs and wrapper results: blockMesh exit0,0.115630s,56676KiB; outflow exit0,0.115375s,94480KiB; backflow exit0,0.115618s,94044KiB. Both complete lifecycle PASS markers correspond to source assertions inspected before execution. Original normal full U/performance, one-sweep shadow and entry normalizer reference checks pass exactly. Case/source pins unchanged. Branch trace0/2 confirms intended outflow/backflow native BC coverage. Candidate-bracket actual p/phi/V hashes and whole-fixture time values unchanged; no unmeasured pre-reference physical-invariance claim.

Native/Frozen reconstruction arithmetic differs: outflow max diagonal8.8817841970012523e−16, backflow4.4408920985006262e−16, maximum absolute normalized residual-link discrepancy1.0842021724855044e−15. Report accurately preserves these without fabricated tolerance or certification.

APPROVE claim: tested two-cell/two-sign actual fvMesh/noncoupled pressureInletOutletVelocity lifecycle slice passed. APPROVE source/evidence-only backup under parent's scope (exclude all executables, SDK/runtime libraries and credentials). This is not approval of all BC states, actual pressure forcing, fault-injection coverage or engineering validation. Real759760-cell case remains HOLD for strict parser/phase/finite/unit and failure-path tests, complete runtime pins, fresh disabled supervisor/case/latch, exact-digest review and separate authorization. No competing code edits or executions were performed by this reviewer.

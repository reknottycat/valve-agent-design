from pathlib import Path
import json,hashlib,re
b=Path(__file__).parent;old=Path('/workspace/scratch/634aa36792d6/valve-held-operator-build-20261026');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prior=json.loads((old/'frozen-candidate.json').read_text());assert all(sha(old/p)==h for p,h in prior.items())
verification={'old_frozen_entries_unchanged':len(prior),'variants':{}}
for mode in ['outflow','backflow']:
 r=json.loads((b/(mode+'-result.json')).read_text());assert r['exit']==0 and not r['timeout'] and r['original_inputs_unchanged'] and r['pinned_sources_unchanged'] and r['case_file_set_unchanged']
 s=(b/(mode+'.log')).read_text();assert len(re.findall('^HOP component ',s,re.M))==3;assert len(re.findall('^HOP checkpoint ',s,re.M))==2;assert len(re.findall('^HOP nativeFrozenResidualDifference ',s,re.M))==6;assert len(re.findall('^MBP summary ',s,re.M))==8
 assert 'FV_MESH_BC_LIFECYCLE_PASS cells 2 backflow '+('1' if mode=='backflow' else '0') in s
 diag=max(map(float,re.findall('maxDiag (\\S+)',s)));residual=max(abs(float(x)) for x in re.findall('difference (\\S+) tolerance_NOT_ASSIGNED',s))
 verification['variants'][mode]=dict(exit=0,wall_seconds=r['wall'],peak_rss_kib=r['peak_rss_kib'],case_files=len(r['all_case_files']),HOP_components=3,HOP_checkpoints=2,native_frozen_normalized_residual_max_difference=residual,native_frozen_diag_max_difference=diag,tolerance='NOT_ASSIGNED',log_sha256=sha(b/(mode+'.log')))
(b/'verification.json').write_text(json.dumps(verification,indent=2)+'\n');print(json.dumps(verification,indent=2))

from pathlib import Path
import json,os,subprocess,resource,time,signal,shlex
B=Path(__file__).parent; state=B/'build-session.json'
assert not state.exists(),'One attempt only; refuse retry'
cmd=json.loads((B/'command-1.json').read_text());(B/'bin').mkdir();(B/'tmp').mkdir()
(B/'command-1.sh.txt').write_text(shlex.join(cmd)+'\n')
r={'attempts':1,'jobs':1,'wall_limit_seconds':90,'cpu_limit_seconds':80,'address_space_bytes':2147483648,'binary_execution_forbidden':True,'closed':False}
state.write_text(json.dumps(r,indent=2)+'\n')
def limits():
 os.setsid();os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648));resource.setrlimit(resource.RLIMIT_CPU,(80,80));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','TMPDIR':str(B/'tmp'),'LD_LIBRARY_PATH':'/workspace/shared/valve-openfoam-quality-20261023/root/usr/lib/dummy:/workspace/shared/valve-openfoam-quality-20261023/root/usr/lib'}
t=time.monotonic(); before=resource.getrusage(resource.RUSAGE_CHILDREN)
with (B/'build-1.log').open('w') as log:
 log.write(shlex.join(cmd)+'\n');log.flush()
 p=subprocess.Popen(cmd,cwd=B,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
 try:r['exit_code']=p.wait(timeout=90);r['timed_out']=False
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);r['exit_code']=p.wait();r['timed_out']=True
r['wall_seconds']=time.monotonic()-t;a=resource.getrusage(resource.RUSAGE_CHILDREN);r['cpu_seconds']=a.ru_utime+a.ru_stime-before.ru_utime-before.ru_stime;r['peak_rss_kib']=a.ru_maxrss;r['closed']=True
state.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(r['exit_code']!=0)

import json,hashlib,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/shared/valve-gmsh-trial-20261023/vendor');import gmsh
r=Path(__file__).parent;qpath=Path('/workspace/shared/valve-step-grading-surface-20261023/evidence/comparison.json');gpath=Path('/workspace/shared/valve-step-grading-volume-20261023/evidence/geometry.json');q=json.loads(qpath.read_text())['graded'];geo={str(x['gmsh_surface']):x for x in json.loads(gpath.read_text())['mapping']};ranking=[]
for f,v in q.items():ranking.append({'face':int(f),'family':geo[f]['family'],'area_mm2':geo[f]['area_mm2'],'bbox_mm':geo[f]['bbox_mm'],'triangles':v['triangles'],'aspect_min_median_P95_P99_max':v['aspect_quantiles_min_median_P95_P99_max'],'edge_quantiles_mm':v['edge_length_quantiles_mm']})
ranking.sort(key=lambda x:-x['aspect_min_median_P95_P99_max'][-1]);out={'all132_ranked':ranking,'source_files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [qpath,gpath]},'target_boundary_mesh':{}}
p=Path('/workspace/shared/valve-step-grading-surface-20261023/fresh-local-surface.msh');gmsh.initialize();gmsh.open(str(p));nt,cs,_=gmsh.model.mesh.getNodes();pos={int(t):p for t,p in zip(nt,np.array(cs).reshape(-1,3))}
for f in [93,102,104,128,130]:
 curves=[]
 for d,c in gmsh.model.getBoundary([(2,f)],combined=False,oriented=False):
  _,_,ns=gmsh.model.mesh.getElements(1,c);ex=np.array([[pos[int(n)] for n in row] for row in np.array(ns[0]).reshape(-1,2)]);le=np.linalg.norm(ex[:,1]-ex[:,0],axis=1);curves.append({'curve':c,'mesh_edges':len(le),'edge_min_median_max_mm':np.percentile(le,[0,50,100]).tolist(),'mesh_z_range_mm':[float(ex[:,:,2].min()),float(ex[:,:,2].max())]})
 out['target_boundary_mesh'][f]=curves
out['source_surface_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();out['no_CAD_reimport_no_meshing']=True;gmsh.finalize();(r/'review.json').write_text(json.dumps(out,indent=2));print(out['target_boundary_mesh'])

def apply_ring(msh, patch):
    # Input is pinned Gmsh 2.2 ASCII. Insert one strict interior node per tetrahedron;
    # children inherit orientation by replacement at the same vertex slot.
    import itertools
    patch={int(t):{int(n):v for n,v in entry[0].items()} for t,entry in patch.items()}
    assert len(patch)==2502 and all(len(b)==4 and min(b.values())>0 and sum(b.values())==1 for b in patch.values()); wanted={n for r in patch.values() for n in r}; positions={}; ids={}; found=set()
    with msh.open() as src,msh.with_suffix('.new').open('x') as dst:
        for line in src:
            dst.write(line)
            if line.strip()=='$Nodes':
                n=int(next(src));dst.write(str(n+len(patch))+'\n');maxnode=0
                for line in itertools.islice(src,n):
                    dst.write(line);a=line.split();i=int(a[0]);maxnode=max(maxnode,i)
                    if i in wanted:positions[i]=[float(x) for x in a[1:]]
                assert positions.keys()==wanted
                for j,(t,b) in enumerate(sorted(patch.items()),1):
                    ids[t]=maxnode+j;p=[sum(positions[i][k]*v for i,v in b.items()) for k in range(3)];dst.write(f'{ids[t]} '+ ' '.join(format(x,'.17g') for x in p)+'\n')
            elif line.strip()=='$Elements':
                n=int(next(src));dst.write(str(n+3*len(patch))+'\n');new=10000000
                for line in itertools.islice(src,n):
                    a=line.split();i=int(a[0]);assert i<10000000
                    if i not in ids:dst.write(line);continue
                    assert a[1]=='4' and i not in found;found.add(i);q=3+int(a[2]);vs=list(map(int,a[q:]));assert set(vs)==patch[i].keys()
                    for j in range(4):
                        child=vs[:];child[j]=ids[i];dst.write(' '.join([str(i if j==0 else new),*a[1:q],*map(str,child)])+'\n');new+=j!=0
    assert found==ids.keys();return msh.with_suffix('.new')

import runpy,itertools,json
from pathlib import Path
import numpy as np
w=Path(__file__).parent;s=runpy.run_path(str(w/'patch_trial.py'));P=s['P'];I=s['I'][s['ring']];fd=s['fd'];best=np.zeros(len(P));bestB=np.zeros((len(P),4));
# Keep the original boundary triangles. A shared outer face is not modified by the choice of interior point.
for nums in itertools.product(range(1,6),repeat=4):
 if sum(nums)!=8:continue
 b=np.array(nums)/8;ctr=np.einsum('j,ijk->ik',b,P); ds=[]
 for j,fi in enumerate(fd):
  ch=np.concatenate([P[:,fi],ctr[:,None,:]],axis=1);inside=np.ones((len(ch),4),bool);inside[:,3]=I[:,j];A=np.stack([np.cross(ch[:,q]-ch[:,p],ch[:,r]-ch[:,p]) for p,q,r in fd],axis=1);A*=inside[:,:,None];A/=(np.linalg.norm(A,axis=2).sum(1)/inside.sum(1))[:,None,None];ds.append(abs(np.linalg.det(A.transpose(0,2,1)@A)))
 d=np.min(ds,axis=0);take=d>best;best[take]=d[take];bestB[take]=b
r={'scope':'local determinant test only; adjacent face weights and whole-mesh quality not certified','old_bad_parents':len(P),'parents_with_all_four_passing':int(np.sum(best>=.001)),'lowest_optimized_child_determinant':float(np.min(best)),'tested_points_per_parent':sum(sum(nums)==8 for nums in itertools.product(range(1,6),repeat=4))}; (w/'ring_opt.json').write_text(json.dumps(r,indent=2));print(r)

v=s['v']; one,two=v['one'],v['two'];vol=v['v']; R=s['ring'];idx=np.full(len(R),-1);idx[R]=np.arange(R.sum()); factors=[]
for face in (one,two):
 cell=face//4; mask=R[cell];a=vol[cell].copy();a[mask]*=bestB[idx[cell[mask]],face[mask]%4];factors.append(a)
x,y=factors; fw=np.minimum(x,y)/(x+y); newly=int(np.sum((v['weights']>=.05)&(fw<.05)));fixed=int(np.sum((v['weights']<.05)&(fw>=.05)));print('NEWLY BAD / FIXED',newly,fixed);r.update(expected_low_weight_faces=int(np.sum(fw<.05)), newly_low_weight_faces=newly, repaired_low_weight_faces=fixed,expected_low_determinant_cells=4657-int(R.sum())); (w/'candidate_prediction.json').write_text(json.dumps(r,indent=2))

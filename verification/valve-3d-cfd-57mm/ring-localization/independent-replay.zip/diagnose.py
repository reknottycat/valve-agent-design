import gzip,hashlib,shutil,json,collections
from pathlib import Path
import numpy as np, gmsh
w=Path(__file__).parent;p=Path('/tmp/valve-cfd-gates-r22/open57-ring-v22-si.msh.gz');assert hashlib.sha256(p.read_bytes()).hexdigest()=='5e3a72898fe148b5fcfcd38bd0d7b7e5636439ae144ada446f7a2982b3e58a81'
with gzip.open(p,'rb') as f,(w/'volume.msh').open('wb') as o:shutil.copyfileobj(f,o)
gmsh.initialize();gmsh.option.setNumber('General.Terminal',0);gmsh.open(str(w/'volume.msh'));tags,coords,_=gmsh.model.mesh.getNodes();xyz=np.zeros((int(tags.max())+1,3));xyz[tags]=coords.reshape(-1,3)*1000; et,en,nodes=gmsh.model.mesh.getElements(3);assert et.tolist()==[4];T=nodes[0].reshape(-1,4).astype(np.int32);assert len(T)==1291975
base=len(xyz)
def key(tri):
    a=np.sort(tri,axis=-1).astype(np.int64);return (a[...,0]*base+a[...,1])*base+a[...,2]
keys=np.empty(T.shape,np.int64);N=len(T);face=[[1,2,3],[0,2,3],[0,1,3],[0,1,2]]
for j,ix in enumerate(face):keys[:,j]=key(T[:,ix]);
idx=np.argsort(keys.ravel());ss=keys.ravel()[idx]; same=ss[1:]==ss[:-1];assert not np.any(same[:-1]&same[1:]);one=idx[:-1][same];two=idx[1:][same];I=np.zeros(N*4,bool);I[one]=1;I[two]=1;I=I.reshape(-1,4);assert np.count_nonzero(I.sum(1)==2)==4213
boundary_id=np.zeros(N*4,np.int32);fs=np.flatnonzero(~I.ravel());fo=np.argsort(keys.ravel()[fs]);fk=keys.ravel()[fs[fo]]
for _,f in gmsh.model.getEntities(2):
    types,te,ns=gmsh.model.mesh.getElements(2,f);assert list(types)==[2];k=key(ns[0].reshape(-1,3));loc=np.searchsorted(fk,k);assert np.array_equal(fk[loc],k);boundary_id[fs[fo[loc]]]=f
assert np.all(boundary_id[fs]>0);boundary_id=boundary_id.reshape(-1,4);gmsh.finalize();det=np.empty(N);v=np.empty(N);centers=np.empty((N,3));
for k in range(0,N,40000):
    sl=slice(k,k+40000);P=xyz[T[sl]];centers[sl]=P.mean(axis=1);v[sl]=np.abs(np.einsum('ij,ij->i',np.cross(P[:,1]-P[:,0],P[:,2]-P[:,0]),P[:,3]-P[:,0]));A=np.stack([np.cross(P[:,q]-P[:,p],P[:,r]-P[:,p]) for p,q,r in face],axis=1);A*=I[sl,:,None];avg=np.linalg.norm(A,axis=2).sum(1)/np.maximum(I[sl].sum(1),1);A/=np.maximum(avg,1e-60)[:,None,None];det[sl]=abs(np.linalg.det(A.transpose(0,2,1)@A))
assert np.all(v>0);bad=det<.001;weights=np.minimum(v[one//4],v[two//4])/(v[one//4]+v[two//4]);bf=weights<.05
print('counts:',bad.sum(),bf.sum(),flush=True);assert (bad.sum(),bf.sum())==(4657,16);E=collections.Counter(tuple(sorted(i[i>0].tolist())) for i in boundary_id[bad]); ids=one[bf];fc=np.array([xyz[T[i//4,face[i%4]]].mean(axis=0) for i in ids]);geom=lambda x:{'z_range':x[:,2].min(initial=1e20).item() if False else [x[:,2].min().item(),x[:,2].max().item()],'r_range': [float(s(np.hypot(x[:,0]-300,x[:,1]))) for s in [np.min,np.max]]};guide=lambda x: (np.hypot(x[:,0]-300,x[:,1])>=30.5)&(np.hypot(x[:,0]-300,x[:,1])<=32.5)&(x[:,2]>=96)&(x[:,2]<=197)
out={'checks':[int(bad.sum()),int(bf.sum())],'two_internal_in_bad':int(np.count_nonzero(bad&(I.sum(1)==2))),'by_internal_faces':{str(i):int(np.sum(bad&(I.sum(1)==i))) for i in range(5)},'boundary_pairs':[[list(p),n,geom(centers[bad & np.all(np.sort(boundary_id,axis=1)==sorted([0]*(4-len(p))+list(p)),axis=1)])] for p,n in E.most_common(10)],'low_weight_faces':geom(fc),'guide_box_counts':[int(guide(centers[bad]).sum()),int(guide(fc).sum())]};print(json.dumps(out,indent=2));(w/'diagnosis.json').write_text(json.dumps(out,indent=2));np.savetxt(w/'local_cells.csv',centers[bad],delimiter=',',fmt='%.9f');np.savetxt(w/'local_faces.csv',fc,delimiter=',',fmt='%.9f')

# Bounded topology trial on the dominant ring. Preserve the four original triangles; no CAD edit.
import runpy
from pathlib import Path
import numpy as np,json
w=Path(__file__).parent;v=runpy.run_path(str(w/'diagnose.py'));T,xyz,I,bd=[v[k] for k in ('T','xyz','I','boundary_id')];ring=np.any(bd==36,axis=1)&(I.sum(1)==2)&v['bad']; assert ring.sum()==2502
P=xyz[T[ring]];cent=P.mean(1);fd=v['face']; counts=[];nn=[]
for j,fi in enumerate(fd):
    child=np.concatenate([P[:,fi],cent[:,None,:]],axis=1)
    # Only face opposite the inserted centre inherits its original boundary status.
    inside=np.ones((len(child),4),bool);inside[:,3]=I[ring,j]
    A=np.stack([np.cross(child[:,q]-child[:,p],child[:,r]-child[:,p]) for p,q,r in fd],axis=1);A*=inside[:,:,None];A/= (np.linalg.norm(A,axis=2).sum(1)/inside.sum(1))[:,None,None];d=np.abs(np.linalg.det(A.transpose(0,2,1)@A));counts.append(d<.001);nn.append(d)
failed=np.stack(counts,axis=1);r={'scope':'local trial: centre-to-four-face subdivision of original failing ring tets only; no whole-valve solver','original_bad_ring_cells':int(ring.sum()),'new_cells':int(failed.size),'new_bad_children':int(failed.sum()),'parents_with_all_children_passing_det':int(np.sum(~failed.any(1))),'min_child_det':float(np.min(nn))};(w/'ring_trial.json').write_text(json.dumps(r,indent=2));print(r)

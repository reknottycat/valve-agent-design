import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/shared/valve-gmsh-trial-20261023/vendor');import gmsh,numpy as np
r=Path(__file__).parent;gmsh.initialize();out={}
for name,path in [('cone688424',Path('/workspace/shared/valve-cone-grading-volume-20261023/fresh-local-surface.msh')),('step759760',Path('/workspace/shared/valve-step-grading-volume-20261023/fresh-local-surface.msh'))]:
 gmsh.clear();gmsh.open(str(path));tags,coords,_=gmsh.model.mesh.getNodes();xyz=np.array(coords).reshape(-1,3);lookup=np.full(int(max(tags))+1,-1,dtype=int);lookup[tags]=np.arange(len(tags));_,_,nd=gmsh.model.mesh.getElements(3);p=xyz[lookup[np.array(nd[0]).reshape(-1,4)]];v=np.linalg.det(np.stack([p[:,1]-p[:,0],p[:,2]-p[:,0],p[:,3]-p[:,0]],axis=1))/6
 # Boundary divergence formula provides a second algebraic volume comparison.
 # Surface triangle ordering is not assumed outward, so use each tet's signed volume only.
 out[name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'tetrahedra':len(v),'nonpositive':int((v<=0).sum()),'determinant_sum_volume_mm3':float(v.sum()),'relative_error_vs_CAD':float(v.sum()/64142426.1438-1)}
a=out['cone688424']['determinant_sum_volume_mm3'];b=out['step759760']['determinant_sum_volume_mm3'];out['delta_mm3']=b-a;out['relative_delta']=b/a-1;out['CAD_unchanged_does_not_mean_discrete_volume_identical']=True
(r/'volume-comparison.json').write_text(json.dumps(out,indent=2));gmsh.finalize();print(json.dumps(out,indent=2))
